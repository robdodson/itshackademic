htmlSuite('core-ajax', function() {
  htmlTest('html/core-ajax.html');
  htmlTest('html/core-ajax-response-and-error.html');
});
