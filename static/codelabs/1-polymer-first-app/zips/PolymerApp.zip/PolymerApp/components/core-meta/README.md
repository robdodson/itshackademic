core-meta
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-meta) for more information.
